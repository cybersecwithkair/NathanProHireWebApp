-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 29, 2024 at 07:16 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fit2104_assignment5`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `phone_number` varchar(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `contractor_id` int(11) DEFAULT NULL,
  `created` datetime DEFAULT current_timestamp(),
  `organisation_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contractors`
--

CREATE TABLE `contractors` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `phone_number` varchar(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contractors`
--

INSERT INTO `contractors` (`id`, `first_name`, `last_name`, `phone_number`, `email`, `created`, `modified`) VALUES
(1, 'John', 'Doe', '412 345 67', 'john.doe@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(2, 'Jane', 'Smith', '412 678 90', 'jane.smith@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(3, 'Michael', 'Brown', '412 234 56', 'michael.brown@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(4, 'Emily', 'Davis', '412 987 65', 'emily.davis@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(5, 'Sarah', 'Wilson', '412 345 98', 'sarah.wilson@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(6, 'David', 'Johnson', '412 567 89', 'david.johnson@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(7, 'Laura', 'Martinez', '412 678 23', 'laura.martinez@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(8, 'Robert', 'Lee', '412 789 34', 'robert.lee@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(9, 'Michelle', 'Harris', '412 890 45', 'michelle.harris@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(10, 'William', 'Clark', '412 901 56', 'william.clark@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(11, 'Jessica', 'Lewis', '412 123 45', 'jessica.lewis@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(12, 'Brian', 'Walker', '412 234 67', 'brian.walker@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(13, 'Olivia', 'Hall', '412 345 78', 'olivia.hall@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(14, 'James', 'Allen', '412 456 89', 'james.allen@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(15, 'Isabella', 'Young', '412 567 90', 'isabella.young@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(16, 'Daniel', 'Wright', '412 678 01', 'daniel.wright@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(17, 'Ava', 'Scott', '412 789 12', 'ava.scott@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(18, 'Matthew', 'Adams', '412 890 23', 'matthew.adams@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(19, 'Sophie', 'Nelson', '412 901 34', 'sophie.nelson@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(20, 'Andrew', 'Carter', '412 123 56', 'andrew.carter@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(21, 'Chloe', 'Mitchell', '412 234 67', 'chloe.mitchell@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(22, 'Ethan', 'Roberts', '412 345 78', 'ethan.roberts@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(23, 'Mia', 'Turner', '412 456 89', 'mia.turner@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(24, 'Lucas', 'Phillips', '412 567 90', 'lucas.phillips@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(25, 'Emma', 'Campbell', '412 678 01', 'emma.campbell@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(26, 'Alexander', 'Parker', '412 789 12', 'alexander.parker@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(27, 'Lily', 'Evans', '412 890 23', 'lily.evans@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(28, 'Jacob', 'Edwards', '412 901 34', 'jacob.edwards@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(29, 'Charlotte', 'Collins', '412 123 45', 'charlotte.collins@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(30, 'Ryan', 'Stewart', '412 234 56', 'ryan.stewart@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(31, 'Amelia', 'Morris', '412 345 67', 'amelia.morris@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(32, 'Aiden', 'Rogers', '412 456 78', 'aiden.rogers@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(33, 'Grace', 'Reed', '412 567 89', 'grace.reed@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(34, 'Noah', 'Cook', '412 678 90', 'noah.cook@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(35, 'Mia', 'Bell', '412 789 01', 'mia.bell@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(36, 'Jack', 'Murphy', '412 890 12', 'jack.murphy@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(37, 'Ella', 'Bailey', '412 901 23', 'ella.bailey@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(38, 'Lucas', 'Rivera', '412 123 34', 'lucas.rivera@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(39, 'Harper', 'Cooper', '412 234 45', 'harper.cooper@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(40, 'Benjamin', 'Richardson', '412 345 56', 'benjamin.richardson@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(41, 'Lily', 'Wood', '412 456 67', 'lily.wood@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(42, 'Mason', 'Cox', '412 567 78', 'mason.cox@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(43, 'Aria', 'Ward', '412 678 89', 'aria.ward@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(44, 'James', 'Foster', '412 789 90', 'james.foster@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(45, 'Zoe', 'James', '412 890 01', 'zoe.james@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(46, 'Elijah', 'Bennett', '412 901 12', 'elijah.bennett@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(47, 'Scarlett', 'Gray', '412 123 23', 'scarlett.gray@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(48, 'Matthew', 'Simmons', '412 234 34', 'matthew.simmons@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(49, 'Evelyn', 'Hayes', '412 345 45', 'evelyn.hayes@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02'),
(50, 'Jack', 'Brooks', '412 456 56', 'jack.brooks@example.com', '2024-10-29 13:12:02', '2024-10-29 13:12:02');

-- --------------------------------------------------------

--
-- Table structure for table `contractor_skills`
--

CREATE TABLE `contractor_skills` (
  `contractor_id` int(11) NOT NULL,
  `skill_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contractor_skills`
--

INSERT INTO `contractor_skills` (`contractor_id`, `skill_id`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10),
(11, 11),
(12, 12),
(13, 13),
(14, 14),
(15, 15),
(16, 1),
(17, 2),
(18, 3),
(19, 4),
(20, 5),
(21, 6),
(22, 7),
(23, 8),
(24, 9),
(25, 10),
(26, 11),
(27, 12),
(28, 13),
(29, 14),
(30, 15),
(31, 1),
(32, 2),
(33, 3),
(34, 4),
(35, 5),
(36, 6),
(37, 7),
(38, 8),
(39, 9),
(40, 10),
(41, 11),
(42, 12),
(43, 13),
(44, 14),
(45, 15),
(46, 1),
(47, 2),
(48, 3),
(49, 4),
(50, 5);

-- --------------------------------------------------------

--
-- Table structure for table `organisations`
--

CREATE TABLE `organisations` (
  `id` int(11) NOT NULL,
  `business_name` varchar(255) NOT NULL,
  `contact_first_name` varchar(255) NOT NULL,
  `contact_last_name` varchar(255) NOT NULL,
  `contact_email` varchar(255) NOT NULL,
  `current_website` varchar(255) NOT NULL,
  `industry` text NOT NULL,
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `organisations`
--

INSERT INTO `organisations` (`id`, `business_name`, `contact_first_name`, `contact_last_name`, `contact_email`, `current_website`, `industry`, `created`, `modified`) VALUES
(1, 'Tech Innovators', 'John', 'Smith', 'john.smith@techinnovators.com', 'http://techinnovators.com', 'Technology', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(2, 'Green Solutions', 'Emily', 'Johnson', 'emily.johnson@greensolutions.com', 'http://greensolutions.com', 'Environmental', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(3, 'Future Enterprises', 'Michael', 'Brown', 'michael.brown@futureenterprises.com', 'http://futureenterprises.com', 'Consulting', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(4, 'Health Hub', 'Sarah', 'Wilson', 'sarah.wilson@healthhub.com', 'http://healthhub.com', 'Healthcare', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(5, 'FinServe Group', 'David', 'Clark', 'david.clark@finservegroup.com', 'http://finservegroup.com', 'Finance', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(6, 'Smart Design', 'Laura', 'Martinez', 'laura.martinez@smartdesign.com', 'http://smartdesign.com', 'Design', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(7, 'Auto Solutions', 'Robert', 'Lee', 'robert.lee@autosolutions.com', 'http://autosolutions.com', 'Automotive', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(8, 'Urban Living', 'Michelle', 'Harris', 'michelle.harris@urbanliving.com', 'http://urbanliving.com', 'Real Estate', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(9, 'Code Wizards', 'William', 'Walker', 'william.walker@codewizards.com', 'http://codewizards.com', 'Software', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(10, 'Creative Minds', 'Jessica', 'Adams', 'jessica.adams@creativeminds.com', 'http://creativeminds.com', 'Marketing', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(11, 'Secure IT', 'Brian', 'Mitchell', 'brian.mitchell@secureit.com', 'http://secureit.com', 'IT Security', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(12, 'Global Trade', 'Olivia', 'Roberts', 'olivia.roberts@globaltrade.com', 'http://globaltrade.com', 'Logistics', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(13, 'Elite Partners', 'James', 'Turner', 'james.turner@elitepartners.com', 'http://elitepartners.com', 'Partnerships', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(14, 'Innovate Health', 'Isabella', 'Scott', 'isabella.scott@innovatehealth.com', 'http://innovatehealth.com', 'Healthcare', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(15, 'NextGen Tech', 'Daniel', 'Carter', 'daniel.carter@nextgentech.com', 'http://nextgentech.com', 'Technology', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(16, 'Bright Future', 'Ava', 'Wright', 'ava.wright@brightfuture.com', 'http://brightfuture.com', 'Education', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(17, 'Green Earth', 'Mia', 'Young', 'mia.young@greenearth.com', 'http://greenearth.com', 'Environmental', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(18, 'Finance Experts', 'Matthew', 'King', 'matthew.king@financeexperts.com', 'http://financeexperts.com', 'Finance', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(19, 'Tech Pioneers', 'Sophie', 'Evans', 'sophie.evans@techpioneers.com', 'http://techpioneers.com', 'Technology', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(20, 'HealthFirst', 'Andrew', 'Green', 'andrew.green@healthfirst.com', 'http://healthfirst.com', 'Healthcare', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(21, 'Market Leaders', 'Chloe', 'Hall', 'chloe.hall@marketleaders.com', 'http://marketleaders.com', 'Marketing', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(22, 'Visionary Designs', 'Ethan', 'Adams', 'ethan.adams@visionarydesigns.com', 'http://visionarydesigns.com', 'Design', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(23, 'Auto Vision', 'Lily', 'Mitchell', 'lily.mitchell@autovision.com', 'http://autovision.com', 'Automotive', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(24, 'Urban Tech', 'Jacob', 'Bennett', 'jacob.bennett@urbantech.com', 'http://urbantech.com', 'Technology', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(25, 'Pro Health', 'Charlotte', 'Collins', 'charlotte.collins@prohealth.com', 'http://prohealth.com', 'Healthcare', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(26, 'Innovative Solutions', 'Ryan', 'Wood', 'ryan.wood@innovativesolutions.com', 'http://innovativesolutions.com', 'Consulting', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(27, 'NextGen Designs', 'Amelia', 'Stewart', 'amelia.stewart@nextgendesigns.com', 'http://nextgendesigns.com', 'Design', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(28, 'Smart Living', 'Lucas', 'Young', 'lucas.young@smartliving.com', 'http://smartliving.com', 'Real Estate', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(29, 'Elite Tech', 'Emma', 'Rogers', 'emma.rogers@elitetech.com', 'http://elitetech.com', 'Technology', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(30, 'Global Solutions', 'Alexander', 'Price', 'alexander.price@globalsolutions.com', 'http://globalsolutions.com', 'Logistics', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(31, 'FinTech Partners', 'Grace', 'Cooper', 'grace.cooper@fintechpartners.com', 'http://fintechpartners.com', 'Finance', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(32, 'Tech Advance', 'Noah', 'Walker', 'noah.walker@techadvance.com', 'http://techadvance.com', 'Technology', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(33, 'Creative Tech', 'Harper', 'James', 'harper.james@creativetech.com', 'http://creativetech.com', 'Design', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(34, 'Health Innovators', 'James', 'Harris', 'james.harris@healthinnovators.com', 'http://healthinnovators.com', 'Healthcare', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(35, 'Tech Savvy', 'Ella', 'Nelson', 'ella.nelson@techsavvy.com', 'http://techsavvy.com', 'Technology', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(36, 'Smart Solutions', 'Zoe', 'Clark', 'zoe.clark@smartsolutions.com', 'http://smartsolutions.com', 'Consulting', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(37, 'Future Health', 'Elijah', 'Scott', 'elijah.scott@futurehealth.com', 'http://futurehealth.com', 'Healthcare', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(38, 'Finance Future', 'Scarlett', 'Green', 'scarlett.green@financefuture.com', 'http://financefuture.com', 'Finance', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(39, 'Urban Innovators', 'Matthew', 'Lee', 'matthew.lee@urbaninnovators.com', 'http://urbaninnovators.com', 'Real Estate', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(40, 'Tech Experts', 'Evelyn', 'Walker', 'evelyn.walker@techexperts.com', 'http://techexperts.com', 'Technology', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(41, 'Global Ventures', 'Jack', 'Martinez', 'jack.martinez@globalventures.com', 'http://globalventures.com', 'Logistics', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(42, 'Elite Finance', 'Emily', 'Roberts', 'emily.roberts@elitefinance.com', 'http://elitefinance.com', 'Finance', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(43, 'Health Solutions', 'Benjamin', 'Adams', 'benjamin.adams@healthsolutions.com', 'http://healthsolutions.com', 'Healthcare', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(44, 'Innovative Designs', 'Lily', 'Smith', 'lily.smith@innovative-designs.com', 'http://innovative-designs.com', 'Design', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(45, 'Auto Experts', 'Mason', 'Brown', 'mason.brown@autoexperts.com', 'http://autoexperts.com', 'Automotive', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(46, 'Tech Innovators', 'Aria', 'Green', 'aria.green@techinnovators.com', 'http://techinnovators.com', 'Technology', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(47, 'NextGen Solutions', 'James', 'Wright', 'james.wright@nextgensolutions.com', 'http://nextgensolutions.com', 'Consulting', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(48, 'Smart Health', 'Lily', 'Young', 'lily.young@smarthealth.com', 'http://smarthealth.com', 'Healthcare', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(49, 'Finance Innovators', 'Jack', 'Evans', 'jack.evans@financeinnovators.com', 'http://financeinnovators.com', 'Finance', '2024-10-29 13:18:04', '2024-10-29 13:18:04'),
(50, 'Urban Future', 'Grace', 'Baker', 'grace.baker@urbanfuture.com', 'http://urbanfuture.com', 'Real Estate', '2024-10-29 13:18:04', '2024-10-29 13:18:04');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `project_name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `management_tool_link` varchar(255) NOT NULL,
  `due_date` datetime NOT NULL,
  `last_checked` datetime DEFAULT NULL,
  `complete` tinyint(1) NOT NULL,
  `contractor_id` int(11) NOT NULL,
  `organisation_id` int(11) NOT NULL,
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `project_name`, `description`, `management_tool_link`, `due_date`, `last_checked`, `complete`, `contractor_id`, `organisation_id`, `created`, `modified`) VALUES
(1, 'Alpha Initiative', 'First phase of the new system development', 'http://pmtool.example.com/alpha', '2024-10-15 00:00:00', '2024-09-01 00:00:00', 0, 7, 3, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(2, 'Beta Rollout', 'Second phase implementation', 'http://pmtool.example.com/beta', '2024-11-01 00:00:00', '2024-09-05 00:00:00', 0, 15, 6, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(3, 'Client Migration', 'Migrate clients to the new platform', 'http://pmtool.example.com/migration', '2024-12-01 00:00:00', '2024-09-10 00:00:00', 0, 12, 2, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(4, 'Data Analytics', 'Develop data analytics tools', 'http://pmtool.example.com/analytics', '2024-10-30 00:00:00', '2024-09-12 00:00:00', 1, 5, 1, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(5, 'Employee Training', 'Training for new system users', 'http://pmtool.example.com/training', '2024-11-15 00:00:00', '2024-09-15 00:00:00', 0, 19, 8, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(6, 'Feature Update', 'Update key features in the application', 'http://pmtool.example.com/feature-update', '2024-12-15 00:00:00', '2024-09-18 00:00:00', 0, 9, 4, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(7, 'Security Audit', 'Conduct a security audit', 'http://pmtool.example.com/security', '2024-10-20 00:00:00', '2024-09-20 00:00:00', 1, 1, 12, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(8, 'Infrastructure Upgrade', 'Upgrade server infrastructure', 'http://pmtool.example.com/infrastructure', '2024-11-30 00:00:00', '2024-09-22 00:00:00', 0, 14, 7, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(9, 'Market Research', 'Research for new market opportunities', 'http://pmtool.example.com/market-research', '2024-12-10 00:00:00', '2024-09-25 00:00:00', 0, 6, 11, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(10, 'Customer Feedback', 'Analyze customer feedback and make improvements', 'http://pmtool.example.com/feedback', '2024-10-25 00:00:00', '2024-09-27 00:00:00', 1, 11, 16, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(11, 'Sales Dashboard', 'Create a new sales dashboard', 'http://pmtool.example.com/sales-dashboard', '2024-10-05 00:00:00', '2024-09-28 00:00:00', 0, 3, 19, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(12, 'Product Launch', 'Launch the new product', 'http://pmtool.example.com/product-launch', '2024-11-10 00:00:00', '2024-09-30 00:00:00', 0, 2, 5, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(13, 'User Experience', 'Improve user experience based on feedback', 'http://pmtool.example.com/ux-improvement', '2024-12-05 00:00:00', '2024-10-01 00:00:00', 0, 20, 9, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(14, 'Tech Support', 'Enhance tech support services', 'http://pmtool.example.com/tech-support', '2024-10-15 00:00:00', '2024-10-02 00:00:00', 0, 13, 14, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(15, 'Data Migration', 'Migrate historical data to new system', 'http://pmtool.example.com/data-migration', '2024-11-05 00:00:00', '2024-10-04 00:00:00', 0, 10, 18, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(16, 'API Integration', 'Integrate new APIs', 'http://pmtool.example.com/api-integration', '2024-12-01 00:00:00', '2024-10-07 00:00:00', 0, 8, 20, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(17, 'Client Onboarding', 'Onboard new clients', 'http://pmtool.example.com/client-onboarding', '2024-10-20 00:00:00', '2024-10-10 00:00:00', 1, 18, 15, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(18, 'Performance Tuning', 'Tune application performance', 'http://pmtool.example.com/performance-tuning', '2024-11-20 00:00:00', '2024-10-12 00:00:00', 0, 4, 2, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(19, 'Backup System', 'Implement new backup system', 'http://pmtool.example.com/backup-system', '2024-12-20 00:00:00', '2024-10-15 00:00:00', 0, 16, 6, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(20, 'Compliance Check', 'Ensure compliance with new regulations', 'http://pmtool.example.com/compliance', '2024-10-25 00:00:00', '2024-10-17 00:00:00', 1, 17, 4, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(21, 'Mobile App', 'Develop a mobile application', 'http://pmtool.example.com/mobile-app', '2024-11-30 00:00:00', '2024-10-20 00:00:00', 0, 22, 10, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(22, 'Customer Portal', 'Build a new customer portal', 'http://pmtool.example.com/customer-portal', '2024-12-15 00:00:00', '2024-10-22 00:00:00', 0, 21, 7, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(23, 'Internal Audit', 'Conduct an internal audit', 'http://pmtool.example.com/internal-audit', '2024-10-10 00:00:00', '2024-10-25 00:00:00', 1, 15, 11, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(24, 'Website Redesign', 'Redesign the company website', 'http://pmtool.example.com/website-redesign', '2024-11-10 00:00:00', '2024-10-27 00:00:00', 0, 9, 12, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(25, 'Vendor Management', 'Improve vendor management processes', 'http://pmtool.example.com/vendor-management', '2024-12-01 00:00:00', '2024-10-30 00:00:00', 0, 4, 13, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(26, 'Staff Recruitment', 'Recruit new staff members', 'http://pmtool.example.com/staff-recruitment', '2024-10-15 00:00:00', '2024-11-01 00:00:00', 0, 6, 18, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(27, 'Product Update', 'Update existing products', 'http://pmtool.example.com/product-update', '2024-11-20 00:00:00', '2024-11-03 00:00:00', 0, 13, 14, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(28, 'Client Feedback', 'Collect and analyze client feedback', 'http://pmtool.example.com/client-feedback', '2024-12-10 00:00:00', '2024-11-05 00:00:00', 0, 11, 6, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(29, 'Server Maintenance', 'Perform server maintenance', 'http://pmtool.example.com/server-maintenance', '2024-10-30 00:00:00', '2024-11-07 00:00:00', 1, 20, 9, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(30, 'Software Upgrade', 'Upgrade the core software', 'http://pmtool.example.com/software-upgrade', '2024-11-15 00:00:00', '2024-11-10 00:00:00', 0, 7, 3, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(31, 'HR System', 'Implement new HR system', 'http://pmtool.example.com/hr-system', '2024-12-01 00:00:00', '2024-11-12 00:00:00', 0, 15, 1, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(32, 'Data Analysis', 'Analyze current data trends', 'http://pmtool.example.com/data-analysis', '2024-10-25 00:00:00', '2024-11-15 00:00:00', 1, 19, 8, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(33, 'CRM Integration', 'Integrate with new CRM', 'http://pmtool.example.com/crm-integration', '2024-11-30 00:00:00', '2024-11-18 00:00:00', 0, 8, 13, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(34, 'Event Planning', 'Plan and execute company events', 'http://pmtool.example.com/event-planning', '2024-12-10 00:00:00', '2024-11-20 00:00:00', 0, 14, 17, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(35, 'Employee Wellness', 'Develop employee wellness programs', 'http://pmtool.example.com/wellness', '2024-10-15 00:00:00', '2024-11-22 00:00:00', 0, 2, 12, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(36, 'Data Security', 'Enhance data security measures', 'http://pmtool.example.com/data-security', '2024-11-05 00:00:00', '2024-11-25 00:00:00', 1, 10, 4, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(37, 'API Development', 'Develop new APIs', 'http://pmtool.example.com/api-development', '2024-12-15 00:00:00', '2024-11-27 00:00:00', 0, 16, 7, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(38, 'Client Support', 'Improve client support services', 'http://pmtool.example.com/client-support', '2024-10-20 00:00:00', '2024-12-01 00:00:00', 0, 21, 18, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(39, 'Training Materials', 'Create training materials', 'http://pmtool.example.com/training-materials', '2024-11-15 00:00:00', '2024-12-05 00:00:00', 1, 8, 16, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(40, 'System Backup', 'Implement system backup processes', 'http://pmtool.example.com/system-backup', '2024-12-01 00:00:00', '2024-12-02 00:00:00', 0, 22, 3, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(41, 'Remote Work Policy', 'Develop a remote work policy', 'http://pmtool.example.com/remote-work', '2024-11-25 00:00:00', '2024-11-06 00:00:00', 1, 6, 10, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(42, 'Budget Review', 'Review and adjust budgets', 'http://pmtool.example.com/budget-review', '2024-10-15 00:00:00', '2024-11-08 00:00:00', 0, 1, 4, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(43, 'Crisis Management', 'Develop a crisis management plan', 'http://pmtool.example.com/crisis-management', '2024-11-01 00:00:00', '2024-11-10 00:00:00', 0, 19, 5, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(44, 'Software Testing', 'Conduct software testing', 'http://pmtool.example.com/software-testing', '2024-12-10 00:00:00', '2024-11-13 00:00:00', 1, 14, 1, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(45, 'Market Analysis', 'Conduct market analysis', 'http://pmtool.example.com/market-analysis', '2024-11-20 00:00:00', '2024-11-15 00:00:00', 0, 7, 6, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(46, 'Community Engagement', 'Engage with the community', 'http://pmtool.example.com/community-engagement', '2024-12-01 00:00:00', '2024-11-17 00:00:00', 0, 8, 3, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(47, 'Sustainability Initiatives', 'Implement sustainability initiatives', 'http://pmtool.example.com/sustainability', '2024-10-30 00:00:00', '2024-11-19 00:00:00', 1, 15, 11, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(48, 'Supply Chain Optimization', 'Optimize supply chain processes', 'http://pmtool.example.com/supply-chain', '2024-11-25 00:00:00', '2024-11-20 00:00:00', 0, 11, 4, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(49, 'Innovation Hub', 'Create an innovation hub', 'http://pmtool.example.com/innovation-hub', '2024-12-15 00:00:00', '2024-11-22 00:00:00', 0, 12, 10, '2024-10-29 13:33:20', '2024-10-29 13:33:20'),
(50, 'Performance Review', 'Conduct performance reviews', 'http://pmtool.example.com/performance-review', '2024-10-15 00:00:00', '2024-11-25 00:00:00', 1, 4, 9, '2024-10-29 13:33:20', '2024-10-29 13:33:20');

-- --------------------------------------------------------

--
-- Table structure for table `project_skills`
--

CREATE TABLE `project_skills` (
  `project_id` int(11) NOT NULL,
  `skills_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `project_skills`
--

INSERT INTO `project_skills` (`project_id`, `skills_id`) VALUES
(1, 7),
(2, 15),
(3, 12),
(4, 5),
(5, 4),
(6, 9),
(7, 1),
(8, 14),
(9, 6),
(10, 11),
(11, 3),
(12, 2),
(13, 5),
(14, 13),
(15, 10),
(16, 8),
(17, 3),
(18, 4),
(19, 1),
(20, 2),
(21, 7),
(22, 6),
(23, 15),
(24, 9),
(25, 4),
(26, 6),
(27, 13),
(28, 11),
(29, 5),
(30, 7),
(31, 15),
(32, 4),
(33, 8),
(34, 14),
(35, 2),
(36, 10),
(37, 1),
(38, 6),
(39, 8),
(40, 7),
(41, 6),
(42, 1),
(43, 4),
(44, 14),
(45, 7),
(46, 8),
(47, 15),
(48, 11),
(49, 12),
(50, 4);

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id`, `name`) VALUES
(1, 'PHP'),
(2, 'JavaScript'),
(3, 'Flutter'),
(4, 'SQL'),
(5, 'Cloud Computing'),
(6, 'Python'),
(7, 'ReactJS'),
(8, 'NodeJS'),
(9, 'Java'),
(10, 'C++'),
(11, 'AWS'),
(12, 'Azure'),
(13, 'Docker'),
(14, 'Kubernetes'),
(15, 'Angular');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `created`, `modified`) VALUES
(1, 'Nathan', 'Smith', 'nathanPro@gmail.com', '$2y$04$jV8d84HEYYHDvPvN35Ijpuyv.2BOrcmPOqu1ezepvVdVK1g.SrHWy', '2024-10-28 16:47:17', '2024-10-28 16:47:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contractor_id_idx` (`contractor_id`),
  ADD KEY `fk_organisation` (`organisation_id`);

--
-- Indexes for table `contractors`
--
ALTER TABLE `contractors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email_idx` (`email`);

--
-- Indexes for table `contractor_skills`
--
ALTER TABLE `contractor_skills`
  ADD PRIMARY KEY (`contractor_id`,`skill_id`),
  ADD KEY `skill_id_ibfk_2` (`skill_id`);

--
-- Indexes for table `organisations`
--
ALTER TABLE `organisations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contractor_id_idx` (`contractor_id`),
  ADD KEY `organisation_id_idx` (`organisation_id`);

--
-- Indexes for table `project_skills`
--
ALTER TABLE `project_skills`
  ADD KEY `project_id_ibfk_1` (`project_id`),
  ADD KEY `skill_id_ibfk_3` (`skills_id`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `contractors`
--
ALTER TABLE `contractors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `organisations`
--
ALTER TABLE `organisations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD CONSTRAINT `contact_us_ibfk_1` FOREIGN KEY (`contractor_id`) REFERENCES `contractors` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_organisation` FOREIGN KEY (`organisation_id`) REFERENCES `organisations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `contractor_skills`
--
ALTER TABLE `contractor_skills`
  ADD CONSTRAINT `contractor_skills_ibfk_1` FOREIGN KEY (`contractor_id`) REFERENCES `contractors` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `skill_id_ibfk_2` FOREIGN KEY (`skill_id`) REFERENCES `skills` (`id`);

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `projects_ibfk_1` FOREIGN KEY (`contractor_id`) REFERENCES `contractors` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `projects_ibfk_2` FOREIGN KEY (`organisation_id`) REFERENCES `organisations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `project_skills`
--
ALTER TABLE `project_skills`
  ADD CONSTRAINT `project_id_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `skill_id_ibfk_3` FOREIGN KEY (`skills_id`) REFERENCES `skills` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
