<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * ContractorSkills Controller
 *
 * @property \App\Model\Table\ContractorSkillsTable $ContractorSkills
 */
class ContractorSkillsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->ContractorSkills->find()
            ->contain(['Contractors', 'Skills']);
        $contractorSkills = $this->paginate($query);

        $this->set(compact('contractorSkills'));
    }

    /**
     * View method
     *
     * @param string|null $id Contractor Skill id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $contractorSkill = $this->ContractorSkills->get($id, contain: ['Contractors', 'Skills']);
        $this->set(compact('contractorSkill'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $contractorSkill = $this->ContractorSkills->newEmptyEntity();
        if ($this->request->is('post')) {
            $contractorSkill = $this->ContractorSkills->patchEntity($contractorSkill, $this->request->getData());
            if ($this->ContractorSkills->save($contractorSkill)) {
                $this->Flash->success(__('The contractor skill has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The contractor skill could not be saved. Please, try again.'));
        }
        $contractors = $this->ContractorSkills->Contractors->find('list', limit: 200)->all();
        $skills = $this->ContractorSkills->Skills->find('list', limit: 200)->all();
        $this->set(compact('contractorSkill', 'contractors', 'skills'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Contractor Skill id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $contractorSkill = $this->ContractorSkills->get($id, contain: []);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $contractorSkill = $this->ContractorSkills->patchEntity($contractorSkill, $this->request->getData());
            if ($this->ContractorSkills->save($contractorSkill)) {
                $this->Flash->success(__('The contractor skill has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The contractor skill could not be saved. Please, try again.'));
        }
        $contractors = $this->ContractorSkills->Contractors->find('list', limit: 200)->all();
        $skills = $this->ContractorSkills->Skills->find('list', limit: 200)->all();
        $this->set(compact('contractorSkill', 'contractors', 'skills'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Contractor Skill id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $contractorSkill = $this->ContractorSkills->get($id);
        if ($this->ContractorSkills->delete($contractorSkill)) {
            $this->Flash->success(__('The contractor skill has been deleted.'));
        } else {
            $this->Flash->error(__('The contractor skill could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
