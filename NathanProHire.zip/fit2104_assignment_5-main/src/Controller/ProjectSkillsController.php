<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * ProjectSkills Controller
 *
 * @property \App\Model\Table\ProjectSkillsTable $ProjectSkills
 */
class ProjectSkillsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->ProjectSkills->find()
            ->contain(['Projects', 'Skills']);
        $projectSkills = $this->paginate($query);

        $this->set(compact('projectSkills'));
    }

    /**
     * View method
     *
     * @param string|null $id Project Skill id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $projectSkill = $this->ProjectSkills->get($id, contain: ['Projects', 'Skills']);
        $this->set(compact('projectSkill'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $projectSkill = $this->ProjectSkills->newEmptyEntity();
        if ($this->request->is('post')) {
            $projectSkill = $this->ProjectSkills->patchEntity($projectSkill, $this->request->getData());
            if ($this->ProjectSkills->save($projectSkill)) {
                $this->Flash->success(__('The project skill has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The project skill could not be saved. Please, try again.'));
        }
        $projects = $this->ProjectSkills->Projects->find('list', limit: 200)->all();
        $skills = $this->ProjectSkills->Skills->find('list', limit: 200)->all();
        $this->set(compact('projectSkill', 'projects', 'skills'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Project Skill id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $projectSkill = $this->ProjectSkills->get($id, contain: []);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $projectSkill = $this->ProjectSkills->patchEntity($projectSkill, $this->request->getData());
            if ($this->ProjectSkills->save($projectSkill)) {
                $this->Flash->success(__('The project skill has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The project skill could not be saved. Please, try again.'));
        }
        $projects = $this->ProjectSkills->Projects->find('list', limit: 200)->all();
        $skills = $this->ProjectSkills->Skills->find('list', limit: 200)->all();
        $this->set(compact('projectSkill', 'projects', 'skills'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Project Skill id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $projectSkill = $this->ProjectSkills->get($id);
        if ($this->ProjectSkills->delete($projectSkill)) {
            $this->Flash->success(__('The project skill has been deleted.'));
        } else {
            $this->Flash->error(__('The project skill could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
