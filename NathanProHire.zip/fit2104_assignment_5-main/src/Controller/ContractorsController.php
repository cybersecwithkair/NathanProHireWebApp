<?php
declare(strict_types=1);

namespace App\Controller;

use Cake\Event\EventInterface;

/**
 * Contractors Controller
 *
 * @property \App\Model\Table\ContractorsTable $Contractors
 */
class ContractorsController extends AppController
{
    /**
     * Initialization hook method.
     *
     * Use this method to add common initialization code like loading components.
     *
     * e.g. `$this->loadComponent('Security');`
     *
     * @return void
     */
    public function beforeFilter(EventInterface $event)
    {
        parent::beforeFilter($event);
        // Configure the login action to not require authentication, preventing
        // the infinite redirect loop issue
        $this->Authentication->addUnauthenticatedActions(['add']);

        if (!$this->Authentication->getIdentity() && $this->request->getParam('action') != 'add') {
            $this->redirect('/users/login');
        }
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {

        $query = $this->Contractors->find('all', [
            'contain' => ['ContractorSkills'],
        ]);

        $query->leftJoinWith('Projects');

        // Select the necessary fields including the project count
        $query->select([
            'id',
            'first_name',
            'last_name',
            'email',
            'project_count' => $query->func()->count('Projects.id'),
            'created',
            'modified',
        ])
            ->groupBy(['Contractors.id']);

        $skillsList = $this->Contractors->ContractorSkills->Skills->find('list', [
            'keyField' => 'id',
            'valueField' => 'name',
        ])->toArray();
        // Get search filters from the request
        $name = $this->request->getQuery('name');
        $email = $this->request->getQuery('email');
        $skills = $this->request->getQuery('skills');
        $sortByProjects = $this->request->getQuery('sort_by_projects');
        // Apply filters
        if (!empty($name)) {
            $query->where([
                'OR' => [
                    'first_name LIKE' => '%' . $name . '%',
                    'last_name LIKE' => '%' . $name . '%',
                ],
            ]);
        }
        if (!empty($email)) {
            $query->where(['email LIKE' => '%' . $email . '%']);
        }
        if (!empty($skills)) {
            // Ensure we get contractors that match all selected skills
            $query->innerJoinWith('ContractorSkills', function ($q) use ($skills) {
                return $q->where(['ContractorSkills.skill_id IN' => $skills]);
            });

            // Grouping to get distinct contractors
            $query->group(['Contractors.id']);
        }
        // Sort by number of projects if specified
        if ($sortByProjects) {
            $query->order(['project_count' => 'DESC']);
        }

        $contractors = $this->paginate($query);

        $this->set(compact('contractors', 'skillsList'));
    }

    /**
     * View method
     *
     * @param string|null $id Contractor id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view(?string $id = null)
    {
        $contractor = $this->Contractors->get($id, ['contain' => ['ContactUs', 'ContractorSkills' => ['Skills'], 'Projects'],
        ]);
        $this->set(compact('contractor'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $contractor = $this->Contractors->newEmptyEntity();
        $skillsList = $this->Contractors->ContractorSkills->Skills->find('list', [
            'keyField' => 'id',
            'valueField' => 'name',
        ])->toArray();

        if ($this->request->is('post')) {
            $contractor = $this->Contractors->patchEntity($contractor, $this->request->getData());
            if ($this->Contractors->save($contractor)) {
                $selectedSkills = $this->request->getData('skills');
                foreach ($selectedSkills as $skillId) {
                    $contractorSkill = $this->Contractors->ContractorSkills->newEmptyEntity();
                    $contractorSkill->contractor_id = $contractor->id;
                    $contractorSkill->skill_id = $skillId;
                    $this->Contractors->ContractorSkills->save($contractorSkill);
                }
                $this->Flash->success(__('The contractor has been saved.'));

                return $this->redirect(['component' => 'user', 'action' => 'login']);
            }
            $this->Flash->error(__('The contractor could not be saved. Please, try again.'));
        }
        $this->set(compact('contractor', 'skillsList'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Contractor id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit(?string $id = null)
    {
        $contractor = $this->Contractors->get($id, ['contain' => ['ContractorSkills']]);
        $skillsList = $this->Contractors->ContractorSkills->Skills->find('list', [
            'keyField' => 'id',
            'valueField' => 'name',
        ])->toArray();

        // Manually create an array of skill IDs associated with the contractor
        $selectedSkills = [];
        $contractorSkills = $this->Contractors->ContractorSkills
            ->find()
            ->select(['skill_id'])
            ->where(['contractor_id' => $id]);

        foreach ($contractorSkills as $skill) {
            $selectedSkills[] = $skill->skill_id;
        }

        if ($this->request->is(['patch', 'post', 'put'])) {
            $contractor = $this->Contractors->patchEntity($contractor, $this->request->getData());
            if ($this->Contractors->save($contractor)) {
                $newSkills = $this->request->getData('skills');
                $this->Contractors->ContractorSkills->deleteAll(['contractor_id' => $id]);
                foreach ($newSkills as $skillId) {
                    $contractorSkill = $this->Contractors->ContractorSkills->newEmptyEntity();
                    $contractorSkill->contractor_id = $id;
                    $contractorSkill->skill_id = $skillId;
                    $this->Contractors->ContractorSkills->save($contractorSkill);
                }
                $this->Flash->success(__('The contractor has been updated.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The contractor could not be updated. Please, try again.'));
        }
        $this->set(compact('contractor', 'skillsList', 'selectedSkills'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Contractor id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete(?string $id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $contractor = $this->Contractors->get($id);
        if ($this->Contractors->delete($contractor)) {
            $this->Flash->success(__('The contractor has been deleted.'));
        } else {
            $this->Flash->error(__('The contractor could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
