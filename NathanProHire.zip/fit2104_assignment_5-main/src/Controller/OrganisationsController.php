<?php
declare(strict_types=1);

namespace App\Controller;

use Cake\Event\EventInterface;

/**
 * Organisations Controller
 *
 * @property \App\Model\Table\OrganisationsTable $Organisations
 */
class OrganisationsController extends AppController
{
    /**
     * Initialization hook method.
     *
     * Use this method to add common initialization code like loading components.
     *
     * e.g. `$this->loadComponent('Security');`
     *
     * @return void
     */
    public function beforeFilter(EventInterface $event)
    {
        parent::beforeFilter($event);
        // Configure the login action to not require authentication, preventing
        // the infinite redirect loop issue
        $this->Authentication->addUnauthenticatedActions(['add']);

        if (!$this->Authentication->getIdentity() && $this->request->getParam('action') != 'add') {
            $this->redirect('/users/login');
        }
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->Organisations->find();

        // Select organization details and count associated projects
        $query->select([
            'id' => 'Organisations.id',
            'business_name' => 'Organisations.business_name',
            'contact_first_name' => 'Organisations.contact_first_name',
            'contact_last_name' => 'Organisations.contact_last_name',
            'contact_email' => 'Organisations.contact_email',
            'current_website' => 'Organisations.current_website',
            'created' => 'Organisations.created',
            'modified' => 'Organisations.modified',
            'project_count' => $query->func()->count('Projects.id')
        ])
            ->leftJoinWith('Projects')  // Join with Projects to count
            ->group(['Organisations.id', 'Organisations.business_name']);  // Group by organisation ID


        // Search by organization name if provided in the query
        $name = $this->request->getQuery('name');
        if (!empty($name)) {
            $query->where(['Organisations.business_name LIKE' => '%' . $name . '%']);
        }
        $sortOrder = $this->request->getQuery('sort_order');
        if ($sortOrder === 'desc') {
            $query->order(['project_count' => 'DESC']);
        } else {
            // Default sorting to ascending order by organization ID or another field
            $query->order(['Organisations.id' => 'ASC']);
        }
        // Paginate the results
        $organisations = $this->paginate($query);

        // Pass the data to the view
        $this->set(compact('organisations'));
    }

    /**
     * View method
     *
     * @param string|null $id Organisation id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $organisation = $this->Organisations->get($id, contain: ['Projects']);

        $this->set(compact('organisation'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $organisation = $this->Organisations->newEmptyEntity();
        if ($this->request->is('post')) {
            $organisation = $this->Organisations->patchEntity($organisation, $this->request->getData());
            if ($this->Organisations->save($organisation)) {
                $this->Flash->success(__('The organisation has been saved.'));

                return $this->redirect(['component' => 'user', 'action' => 'login']);
            }
            $this->Flash->error(__('The organisation could not be saved. Please, try again.'));
        }
        $this->set(compact('organisation'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Organisation id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $organisation = $this->Organisations->get($id, contain: []);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $organisation = $this->Organisations->patchEntity($organisation, $this->request->getData());
            if ($this->Organisations->save($organisation)) {
                $this->Flash->success(__('The organisation has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The organisation could not be saved. Please, try again.'));
        }
        $this->set(compact('organisation'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Organisation id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $organisation = $this->Organisations->get($id);
        if ($this->Organisations->delete($organisation)) {
            $this->Flash->success(__('The organisation has been deleted.'));
        } else {
            $this->Flash->error(__('The organisation could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
