<?php
declare(strict_types=1);

namespace App\Controller;

use Cake\Event\EventInterface;

/**
 * Projects Controller
 *
 * @property \App\Model\Table\ProjectsTable $Projects
 */
class ProjectsController extends AppController
{
    /**
     * Initialization hook method.
     *
     * Use this method to add common initialization code like loading components.
     *
     * e.g. `$this->loadComponent('Security');`
     *
     * @return void
     */
    public function beforeFilter(EventInterface $event)
    {
        parent::beforeFilter($event);

        if (!$this->Authentication->getIdentity() && $this->request->getParam('action') != 'display') {
            $this->redirect('/');
        }
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->Projects->find()
            ->contain([
                'Contractors',
                'Organisations',
                'ProjectSkills' => ['Skills'],
            ]);

        // Retrieve skills list for the filter checkboxes
        $skillsList = $this->Projects->ProjectSkills->Skills->find('list', [
            'keyField' => 'id',
            'valueField' => 'name',
        ])->toArray();

        // Retrieve possible statuses for the dropdown filter
        $statusList = [
            '' => 'Select Status',
            0 => 'Incomplete',
            1 => 'Complete',
        ];

        // Retrieve filter criteria from query parameters
        $status = $this->request->getQuery('status');
        $skills = $this->request->getQuery('skills');
        $startDate = $this->request->getQuery('start_date');
        $endDate = $this->request->getQuery('end_date');
        $skillsKeyword = $this->request->getQuery('skills_keyword');

        // Apply filters for project name
        if (!empty($skillsKeyword)) {
            $query->matching('ProjectSkills.Skills', function ($q) use ($skillsKeyword) {
                return $q->where(['Skills.name LIKE' => "%$skillsKeyword%"]);
            });
        }

        // Apply filter for status
        if ($status !== null) {
            $query->where(['projects.complete' => $status]);
        }

        // Apply filters for skills
        if (!empty($skills)) {
            $query->matching('ProjectSkills', function ($q) use ($skills) {
                return $q->where(['ProjectSkills.skills_id IN' => $skills]);
            });
        }

        // Apply date range filter
        if (!empty($startDate) && !empty($endDate)) {
            $query->where([
                'Projects.due_date >=' => $startDate,
                'Projects.due_date <=' => $endDate,
            ]);
        }
        $projects = $this->paginate($query);
        $this->set(compact('projects', 'skillsList', 'statusList'));
    }

    /**
     * View method
     *
     * @param string|null $id Project id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view(?string $id = null)
    {
        $project = $this->Projects->get($id, ['contain' => ['Contractors' => ['ContractorSkills' => ['Skills']], 'Organisations'],
        ]);
        $this->set(compact('project'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $project = $this->Projects->newEmptyEntity();
        if ($this->request->is('post')) {
            $project = $this->Projects->patchEntity($project, $this->request->getData());
            if ($this->Projects->save($project)) {
                $this->Flash->success(__('The project has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The project could not be saved. Please, try again.'));
        }
        $contractors = $this->Projects->Contractors->find('list', limit: 200)->all();
        $organisations = $this->Projects->Organisations->find('list', limit: 200)->all();
        $this->set(compact('project', 'contractors', 'organisations'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Project id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit(?string $id = null)
    {
        $project = $this->Projects->get($id, contain: []);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $project = $this->Projects->patchEntity($project, $this->request->getData());
            if ($this->Projects->save($project)) {
                $this->Flash->success(__('The project has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The project could not be saved. Please, try again.'));
        }
        $contractors = $this->Projects->Contractors->find('list', limit: 200)->all();
        $organisations = $this->Projects->Organisations->find('list', limit: 200)->all();
        $this->set(compact('project', 'contractors', 'organisations'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Project id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete(?string $id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $project = $this->Projects->get($id);
        if ($this->Projects->delete($project)) {
            $this->Flash->success(__('The project has been deleted.'));
        } else {
            $this->Flash->error(__('The project could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
