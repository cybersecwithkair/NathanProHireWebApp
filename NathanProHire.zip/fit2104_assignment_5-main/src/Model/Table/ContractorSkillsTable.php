<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * ContractorSkills Model
 *
 * @property \App\Model\Table\ContractorsTable&\Cake\ORM\Association\BelongsTo $Contractors
 * @property \App\Model\Table\SkillsTable&\Cake\ORM\Association\BelongsTo $Skills
 *
 * @method \App\Model\Entity\ContractorSkill newEmptyEntity()
 * @method \App\Model\Entity\ContractorSkill newEntity(array $data, array $options = [])
 * @method array<\App\Model\Entity\ContractorSkill> newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\ContractorSkill get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \App\Model\Entity\ContractorSkill findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \App\Model\Entity\ContractorSkill patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\App\Model\Entity\ContractorSkill> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\ContractorSkill|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \App\Model\Entity\ContractorSkill saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\App\Model\Entity\ContractorSkill>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\ContractorSkill>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\ContractorSkill>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\ContractorSkill> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\ContractorSkill>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\ContractorSkill>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\ContractorSkill>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\ContractorSkill> deleteManyOrFail(iterable $entities, array $options = [])
 */
class ContractorSkillsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('contractor_skills');
        $this->setDisplayField('skill_id');
        $this->setPrimaryKey(['contractor_id', 'skill_id']);

        $this->belongsTo('Contractors', [
            'foreignKey' => 'contractor_id',
            'joinType' => 'INNER',
        ]);
        $this->belongsTo('Skills', [
            'foreignKey' => 'skill_id',
            'joinType' => 'INNER',
        ]);
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['contractor_id'], 'Contractors'), ['errorField' => 'contractor_id']);
        $rules->add($rules->existsIn(['skill_id'], 'Skills'), ['errorField' => 'skill_id']);

        return $rules;
    }
}
