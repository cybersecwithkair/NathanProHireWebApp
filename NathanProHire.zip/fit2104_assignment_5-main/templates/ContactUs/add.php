<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\ContactU $contactU
 * @var \Cake\Collection\CollectionInterface|string[] $contractors
 */
?>
<div class="row">
    <div class="column">
        <div class="contactUs form content">
            <?= $this->Form->create($contactU) ?>
            <fieldset>
                <legend><?= __('Contact Us') ?></legend>
                <?php
                    echo $this->Form->control('first_name');
                    echo $this->Form->control('last_name');
                    echo $this->Form->control('phone_number');
                    echo $this->Form->control('email');
                    echo $this->Form->control('message');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
