<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\ContactU $contactU
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(
                __('Assign Contractor/Organisation'),
                ['action' => 'edit', $contactU->id],
                ['class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(
                __('Mark as Replied'),
                ['action' => 'markRep', $contactU->id],
                ['class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Contact Us'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="contactUs view content">
            <h3>Message</h3>
            <table>
                <tr>
                    <th><?= __('First Name') ?></th>
                    <td><?= h($contactU->first_name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Last Name') ?></th>
                    <td><?= h($contactU->last_name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Phone Number') ?></th>
                    <td><?= h($contactU->phone_number) ?></td>
                </tr>
                <tr>
                    <th><?= __('Email') ?></th>
                    <td><?= h($contactU->email) ?></td>
                </tr>
                <tr>
                    <th><?= __('Contractor') ?></th>
                    <td><?= $contactU->hasValue('contractor') ? $this->Html->link($contactU->contractor->first_name, ['controller' => 'Contractors', 'action' => 'view', $contactU->contractor->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Organisation Id') ?></th>
                    <td><?= $contactU->organisation_id === null ? '' : $this->Number->format($contactU->organisation_id) ?></td>
                </tr>
            </table>
            <div class="text">
                <strong><?= __('Message') ?></strong>
                <blockquote>
                    <?= $this->Text->autoParagraph(h($contactU->message)); ?>
                </blockquote>
            </div>
        </div>
    </div>
</div>
