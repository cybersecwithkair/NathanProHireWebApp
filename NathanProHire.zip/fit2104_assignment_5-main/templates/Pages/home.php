<?php
/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link      https://cakephp.org CakePHP(tm) Project
 * @since     0.10.0
 * @license   https://opensource.org/licenses/mit-license.php MIT License
 * @var \App\View\AppView $this
 */

$this->disableAutoLayout();

?>
<!DOCTYPE html>
<html>
<head>
    <?= $this->Html->charset() ?>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>
        CakePHP: the rapid development PHP framework:
        <?= $this->fetch('title') ?>
    </title>
    <?= $this->Html->meta('icon') ?>

    <?= $this->Html->css(['normalize.min', 'milligram.min', 'fonts', 'cake', 'home']) ?>

    <?= $this->fetch('meta') ?>
    <?= $this->fetch('css') ?>
    <?= $this->fetch('script') ?>
</head>
<body>
    <header>
        <div class="container text-center">
            <h1>
                Welcome to Nathan Pro<span>Hire</span>
            </h1>
        </div>
    </header>
    <main class="main">
        <div class="container">
            <a class="button" href="/fit2104_assignment_5/users/login">Log In</a>
        </div>
        <div class="container">
            <div class="row">
                <div class="column headings">
                    <h3>What is this <span>about</span>?</h3>
                </div>
                <div class="column headings">
                    <h3>How can you <span>contribute</span>?</h3>
                </div>
            </div>
            <div class="row">
                <div class="column content home-page">
                    <p class="home-text">
                        Nathan Pro Hire provides a platform for contractors to connect with organisations
                        that need their services. It is a platform that allows contractors to showcase their
                        skills and experience to organisations that need their services. Organisations can
                        post projects that they need help with and contractors are assigned to these projects
                        based on their skills and experience.
                    </p>
                </div>
                <div class="column content home-page">
                    <p class="home-text">
                        If you are a contractor, you can sign up and create a profile that showcases your skills
                        and experience. If you are an organisation, you can sign up and email nathan projects that you
                        want to help with.
                    </p>
                    <a class="button" href="/fit2104_assignment_5/contractors/add">Join as a Contractor</a>
                    <a class="button" href="/fit2104_assignment_5/organisations/add">Join as a Organisation</a>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="column headings">
                    <h3>Need any <span>help</span>?</h3>
                </div>
            </div>
            <div class="row">
                <div class="column content home-page">
                    <p class="home-text">
                        If you have any questions or need help, please feel free to contact us. We are here to help you.
                    </p>
                    <a class="button" href="/fit2104_assignment_5/contact-us/add">Contact Us</a>
                </div>
            </div>
        </div>
    </main>
</body>
</html>
