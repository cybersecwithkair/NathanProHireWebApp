<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\Project> $projects
 * @var array $statusList
 * @var array $skillsList
 */
?>
<div class="projects index content">
    <?= $this->Html->link(__('New Project'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Projects') ?></h3>
    <div class="content">
        <?= $this->Form->create(null, ['type' => 'get']) ?>
        <fieldset>
            <div class="row">
                <div class="column"><?= $this->Form->control('skills_keyword', [
                        'placeholder' => 'Search by Skills keyword',
                        'value' => $this->request->getQuery('skills_keyword'),
                    ]); ?></div>
                <div class="column"><?= $this->Form->control('status', [
                        'type' => 'select',
                        'options' => $statusList,
                        'empty' => true,
                        'value' => $this->request->getQuery('status'),
                    ]); ?></div>
            </div>
            <div class="row">
                <div class="column">
                    <?= $this->Form->control('skills', [
                        'options' => $skillsList,
                        'multiple' => 'checkbox',
                        'label' => 'Select Skills',
                        'value' => $this->request->getQuery('skills') // Get previously selected skills
                    ]); ?>
                </div>
                <div class="column">
                    <?= $this->Form->control('start_date', [
                        'type' => 'date',
                        'value' => $this->request->getQuery('start_date'),
                        'placeholder' => 'Start Date',
                    ]); ?>
                    <?= $this->Form->control('end_date', [
                        'type' => 'date',
                        'value' => $this->request->getQuery('end_date'),
                        'placeholder' => 'End Date',
                    ]); ?>
                </div>
            </div>
        </fieldset>
        <?= $this->Form->button(__('Search')) ?>
        <?= $this->Form->end() ?>
    </div>

    <div class="table-responsive">
        <table>
            <thead>
            <tr>
                <th><?= $this->Paginator->sort('id') ?></th>
                <th><?= $this->Paginator->sort('project_name') ?></th>
                <th><?= $this->Paginator->sort('due_date') ?></th>
                <th><?= $this->Paginator->sort('complete') ?></th>
                <th><?= $this->Paginator->sort('contractors') ?></th>
                <th><?= $this->Paginator->sort('organisations') ?></th>
                <th><?= __('Skills') ?></th> <!-- New column for Skills -->
                <th class="actions"><?= __('Actions') ?></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($projects as $project): ?>
                <tr>
                    <td><?= h($project->id) ?></td>
                    <td><?= h($project->project_name) ?></td>
                    <td><?= h($project->due_date) ?></td>
                    <td><?= h($project->complete) == 1 ? "Yes" : "No" ?></td>
                    <td><?= $project->hasValue('contractor') ? $this->Html->link($project->contractor->first_name, ['controller' => 'Contractors', 'action' => 'view', $project->contractor->id]) : '' ?></td>
                    <td><?= $project->hasValue('organisation') ? $this->Html->link($project->organisation->business_name, ['controller' => 'Organisations', 'action' => 'view', $project->organisation->id]) : '' ?></td>
                    <td>
                        <?php if (!empty($project->project_skills)) : ?>
                            <ul>
                                <?php foreach ($project->project_skills as $projectSkill) : ?>
                                    <li><?= h($projectSkill->skill->name) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        <?php else: ?>
                            <p><?= __('No skills found for this contractor.') ?></p>
                        <?php endif; ?>
                    </td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $project->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $project->id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $project->id], ['confirm' => __('Are you sure you want to delete # {0}?', $project->id)]) ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
