<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\Contractor> $contractors
 * @var array $skillsList
 */
?>
<div class="contractors index content">
    <?= $this->Html->link(__('New Contractor'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Contractors') ?></h3>
    <div class="content">
        <?= $this->Form->create(null, ['type' => 'get']) ?>
        <fieldset>
            <div class="row">
                <div class="column"><?= $this->Form->control('name', [
                        'placeholder' => 'Search by Name (First or Last)',
                        'value' => $this->request->getQuery('name'),
                    ]); ?></div>
                <div class="column"><?= $this->Form->control('email', [
                        'placeholder' => 'Search by Email',
                        'value' => $this->request->getQuery('email'),
                    ]); ?></div>
            </div>
            <div class="row">
                <div class="column">
                    <?= $this->Form->control('skills', [
                        'options' => $skillsList,
                        'multiple' => 'checkbox',
                        'label' => 'Select Skills',
                        'value' => $this->request->getQuery('skills') // Get previously selected skills
                    ]); ?>
                </div>
                <div class="column">
                    <?= $this->Form->control('sort_by_projects', [
                        'type' => 'select',
                        'options' => [
                            '' => 'Sort By',
                            '1' => 'Number of Projects (Descending)',
                        ],
                        'empty' => true,
                        'value' => $this->request->getQuery('sort_by_projects'),
                    ]); ?>
                </div>
            </div>
        </fieldset>
        <?= $this->Form->button(__('Search')) ?>
        <?= $this->Form->end() ?>
    </div>
    <div class="table-responsive">
        <table>
            <thead>
            <tr>
                <th><?= $this->Paginator->sort('id') ?></th>
                <th><?= $this->Paginator->sort('first_name') ?></th>
                <th><?= $this->Paginator->sort('last_name') ?></th>
                <th><?= $this->Paginator->sort('email') ?></th>
                <th><?= $this->Paginator->sort('created') ?></th>
                <th><?= $this->Paginator->sort('modified') ?></th>
                <th><?= $this->Paginator->sort('project_count', 'Projects') ?></th>
                <th class="actions"><?= __('Actions') ?></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($contractors as $contractor): ?>
                <tr>
                    <td><?= $this->Number->format($contractor->id) ?></td>
                    <td><?= h($contractor->first_name) ?></td>
                    <td><?= h($contractor->last_name) ?></td>
                    <td><?= h($contractor->email) ?></td>
                    <td><?= h($contractor->created) ?></td>
                    <td><?= h($contractor->modified) ?></td>
                    <td><?= h($contractor->project_count) ?></td> <!-- Assuming project count is part of your entity -->
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $contractor->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $contractor->id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $contractor->id], ['confirm' => __('Are you sure you want to delete # {0}?', $contractor->id)]) ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
