<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Contractor $contractor
 * @var array $skillsList
 */
?>
<div class="row">
    <div class="column">
        <div class="contractors form content">
            <?= $this->Form->create($contractor) ?>
            <fieldset>
                <legend><?= __('Add Contractor') ?></legend>
                <?php
                echo $this->Form->control('first_name', ['label' => 'First Name']);
                echo $this->Form->control('last_name', ['label' => 'Last Name']);
                echo $this->Form->control('phone_number', ['label' => 'Phone Number']);
                echo $this->Form->control('email', ['label' => 'Email']);

                // Multi-select checkbox for skills
                echo $this->Form->control('skills', [
                    'type' => 'select',
                    'multiple' => 'checkbox',
                    'options' => $skillsList,
                    'label' => 'Skills',
                ]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
